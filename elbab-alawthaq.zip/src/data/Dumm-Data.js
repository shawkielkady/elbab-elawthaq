import villImg from '../assets/images/villa.jpg';
import towerImg from '../assets/images/tower.jpg';
import apartmentImg from '../assets/images/apartment.jpg';
import groupsImg from '../assets/images/groups.PNG';
export const counters = [
    { number: '+250', label: 'وحدة' },
    { number: '+120', label: 'مشروع' },
    { number: '+80',  label: 'شريك' },
    { number: '+15',  label: 'سنة خبرة' },
  ];
export   const specialProducts = [
    { id: 1, name: 'فيلا فاخرة', img: villImg },
    { id: 2, name: 'شقة مطلة على البحر', img: villImg },
    { id: 3, name: 'منزل ريفي', img: villImg},
  ];
export const whoUsCategoriesData =[{
  id:0, name:"ابراج", img:towerImg
},
{
  id:1, name:"فلل", img:villImg
},
{
  id:2, name:"شقق", img:apartmentImg
},
{
  id:3, name:"مجمعات", img:groupsImg
},
];