import React from 'react'

/**
* @author
* @function WhoUsSec
**/

export const WhoUsSec = () => {
  const points = [
    { icon: "fa-sun", text: "فرق فنيّ متخصص وخبرة عالية في المجال" },
    { icon: "fa-building", text: "استخدام أحدث تقنيات البناء والتطوير" },
    { icon: "fa-clipboard-check", text: "متابعة دقيقة لجميع مراحل التنفيذ" },
    { icon: "fa-chart-line", text: "ضمان تسليم المشاريع في الوقت المحدد" },
  ];

  return (
    <section className="whyus-modern-section">
      <div className="container">
        {/* العنوان */}
        <h2 className="section-title">لماذا نحن؟</h2>

        <div className="whyus-content">
          {/* القائمة */}
          <div className="whyus-list">
            {points.map((item, index) => (
              <div key={index} className="whyus-item">
                <i className={`fa-solid ${item.icon}`}></i>
                <span>{item.text}</span>
              </div>
            ))}
          </div>

          {/* الأيقونة الافتراضية */}
          <div className="whyus-person">
            <div className="whyus-avatar">
              <i className="fa-solid fa-user"></i>
            </div>
            <div className="whyus-person-text">
              <p>
                متخصصون في تغيير نمط الحياة وتقديم حلول مبتكرة للسكن العصري
              </p>
              <h4>فريق  الباب الأوثق</h4>
              <span>الخبرة تصنع الفرق</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};