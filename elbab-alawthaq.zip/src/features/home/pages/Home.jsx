import React from 'react';
import '../home.css';

import { SliderSection } from '../components/Slider-section.jsx';
import { CounterSection } from '../../../components/Counter-section.jsx';
import { SpecialUnits } from '../components/Special-Units.jsx';

export const Home = () => {
  return (
    <>
    <SliderSection/>
    <CounterSection />
    <SpecialUnits id='special-units' address=' الوحدات العقارية المميزة'/>
    <SpecialUnits address='  عقارات للبيع '/>
    <SpecialUnits address='  عقارات للإيجار '/>
    <SpecialUnits address='   فيلات '/>

    <SpecialUnits address='  مزارع و استراحات '/>

    </>
  );
};
